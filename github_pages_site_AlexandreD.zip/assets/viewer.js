
/* Minimal PDF viewer using PDF.js (no build step). */
(function () {
  const pdfjsLib = window['pdfjs-dist/build/pdf'];
  if (!pdfjsLib) {
    console.error('PDF.js not loaded');
    return;
  }

  const pdfUrl = document.documentElement.getAttribute('data-pdf');
  const title = document.documentElement.getAttribute('data-title') || 'Livre';
  const container = document.getElementById('pages');
  const status = document.getElementById('status');
  const downloadTop = document.getElementById('downloadTop');
  const downloadBottom = document.getElementById('downloadBottom');

  document.getElementById('bookTitle').textContent = title;

  downloadTop.setAttribute('href', pdfUrl);
  downloadBottom.setAttribute('href', pdfUrl);

  // Required for some CDNs
  pdfjsLib.GlobalWorkerOptions.workerSrc =
    'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.6.82/pdf.worker.min.js';

  const loadingTask = pdfjsLib.getDocument({
    url: pdfUrl,
    // CORS: PDFs are served from same origin (GitHub Pages), so OK.
  });

  loadingTask.promise.then(async (pdf) => {
    status.textContent = `Chargement terminé · ${pdf.numPages} pages`;

    // Render pages sequentially to keep memory reasonable.
    for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
      const page = await pdf.getPage(pageNum);

      // Scale: render at ~1300px wide for crispness, then CSS scales down.
      const viewport = page.getViewport({ scale: 1.0 });
      const targetWidth = Math.min(1300, viewport.width);
      const scale = targetWidth / viewport.width;
      const scaledViewport = page.getViewport({ scale });

      const pageWrap = document.createElement('div');
      pageWrap.className = 'page';

      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d', { alpha: false });

      canvas.width = Math.floor(scaledViewport.width);
      canvas.height = Math.floor(scaledViewport.height);

      pageWrap.appendChild(canvas);
      container.appendChild(pageWrap);

      const renderTask = page.render({
        canvasContext: ctx,
        viewport: scaledViewport,
      });

      await renderTask.promise;
    }
  }).catch((err) => {
    console.error(err);
    status.textContent = "Erreur : impossible d'afficher le PDF. Utilise le bouton Download.";
  });
})();
